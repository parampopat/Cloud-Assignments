# Homework-2
Smart Door Authentication System

# Contributors
Kartik Balasubramaniam(kb3127) & Param Popat(pvp2109)

# Documentation
**Core Functions**
```xyz.py```